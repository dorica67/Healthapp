package com.health.app.activities

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.util.TimeUtils
import android.view.View
import android.widget.Toast
import com.google.firebase.FirebaseException
import com.google.firebase.auth.*
import com.health.app.R
import com.health.app.databinding.ActivityOtpBinding
import java.util.concurrent.TimeUnit

class OTP : AppCompatActivity() {

    private var forceResendingToken: PhoneAuthProvider.ForceResendingToken?  = null
    private  var mCallbacks : PhoneAuthProvider.OnVerificationStateChangedCallbacks? = null
    private var mVerificationId : String?=null
    private  lateinit var firebaseAuth: FirebaseAuth

    private lateinit var binding : ActivityOtpBinding

    private val tag = "MAIN_TAG"

    private lateinit var progressDialog: ProgressDialog
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOtpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.numberll.visibility = View.VISIBLE
        binding.codell.visibility = View.GONE

        firebaseAuth = FirebaseAuth.getInstance()
        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Please wait")
        progressDialog.setCanceledOnTouchOutside(false)
        mCallbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
            override fun onVerificationCompleted(phoneCredential: PhoneAuthCredential) {

                signInWithPhoneAuthCredentials(phoneCredential)
            }

            override fun onVerificationFailed(e: FirebaseException) {

                progressDialog.dismiss()
                Toast.makeText(this@OTP,"${e.message}",Toast.LENGTH_LONG).show()

            }

            override fun onCodeSent(verficationId: String, token: PhoneAuthProvider.ForceResendingToken) {

                Log.d(tag,"onCodeSent: $verficationId")
                mVerificationId = verficationId
                forceResendingToken = token
                progressDialog.dismiss()
                binding.numberll.visibility = View.GONE
                binding.codell.visibility = View.VISIBLE
                Toast.makeText(this@OTP,"Verification Code Sent...",Toast.LENGTH_LONG).show()
                binding.codeDescription.text = "Please type the verfication code we sent to ${binding.etNumber.text.toString().trim()}"
            }

        }
        binding.btnContinue.setOnClickListener {

            val number = binding.etNumber.text.toString().trim()
            if (TextUtils.isEmpty(number)){
                Toast.makeText(this@OTP,"please enter phone number...",Toast.LENGTH_LONG).show()

            }
            else{
                startPhoneNumberVerification(number)
            }
        }
        binding.btnVerify.setOnClickListener {

            val code = binding.etCode.text.toString().trim()
            if (TextUtils.isEmpty(code)){
                Toast.makeText(this@OTP,"please enter verification code...",Toast.LENGTH_LONG).show()

            }
            else{
                verifyPhoneNumberWithCode(mVerificationId,code)
            }
        }
        binding.resedCode.setOnClickListener {
            val number = binding.etNumber.text.toString().trim()
            if (TextUtils.isEmpty(number)){
                Toast.makeText(this@OTP,"please enter phone number...",Toast.LENGTH_LONG).show()

            }
            else{
                resendVerificationCode(number, forceResendingToken!!)
            }
        }
    }
    private fun startPhoneNumberVerification(phone: String){
        progressDialog.setMessage("verifying phone number")
        progressDialog.show()

        val option = PhoneAuthOptions.newBuilder(firebaseAuth)
            .setPhoneNumber(phone)
            .setTimeout(60L,TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(mCallbacks!!)
            .build()

        PhoneAuthProvider.verifyPhoneNumber(option)
    }
    private fun  resendVerificationCode(phone: String,token:PhoneAuthProvider.ForceResendingToken){
        progressDialog.setMessage("Resending Code")
        progressDialog.show()

        val option = PhoneAuthOptions.newBuilder(firebaseAuth)
            .setPhoneNumber(phone)
            .setTimeout(60L,TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(mCallbacks!!)
            .setForceResendingToken(token)
            .build()

        PhoneAuthProvider.verifyPhoneNumber(option)
    }
    private fun verifyPhoneNumberWithCode(verficationId:String?,code:String){
    progressDialog.setMessage("Verifying Code...")
        progressDialog.show()
        val credentials = PhoneAuthProvider.getCredential(verficationId!!,code)
        signInWithPhoneAuthCredentials(credentials)

    }

    private fun signInWithPhoneAuthCredentials(credentials: PhoneAuthCredential) {
        progressDialog.setMessage("Logging In..")
        progressDialog.show()
        firebaseAuth.signInWithCredential(credentials)
            .addOnSuccessListener {

                progressDialog.dismiss()
                val phone = firebaseAuth.currentUser!!.phoneNumber
                Toast.makeText(this,"Logged in as $phone",Toast.LENGTH_LONG).show()
                val intent = Intent(this,Dashboard::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                intent.putExtra("type","otp")
                startActivity(intent)
                finish()
            }.addOnFailureListener { e->
                progressDialog.dismiss()
                Toast.makeText(this,"${e.message}",Toast.LENGTH_LONG).show()
            }
    }
}