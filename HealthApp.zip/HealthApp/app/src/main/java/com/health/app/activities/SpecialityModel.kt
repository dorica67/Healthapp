package com.health.app.activities

class SpecialityModel(var name: String, var image: Int)