package com.health.app.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.health.app.R
import com.health.app.databinding.ActivityLoginWithEmailBinding
import com.health.app.databinding.ActivitySignUpWithEmailBinding

class LoginWithEmail : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityLoginWithEmailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginWithEmailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        binding.btnLogin.setOnClickListener {
            signin()
        }
        binding.tvRegister.setOnClickListener {
            val intent = Intent(this,SignUpWithEmail::class.java)
            startActivity(intent)
        }
    }
    private fun signin() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(this, "Please Enter email", Toast.LENGTH_LONG).show()
            binding.etEmail.error = "Please Enter email"
        }
        if (TextUtils.isEmpty(password) || password.length < 8 ) {
            Toast.makeText(this, "Please Enter password at least 8 characters", Toast.LENGTH_LONG).show()
            binding.etPassword.error = "Please Enter password at least 8 characters"
        }else{
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                      
                        val user = auth.currentUser
                        val intent = Intent(this,Dashboard::class.java)
                        intent.putExtra("type","email")
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)                    } else {
                        
                        Toast.makeText(baseContext, "Authentication failed.",
                            Toast.LENGTH_SHORT).show()
                    }
                }
        }

    }

}