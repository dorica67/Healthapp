package com.health.app.activities.nearByDoctors

import android.Manifest
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.OnMapReadyCallback
import com.health.app.activities.nearByDoctors.NearByListModel
import android.location.LocationManager
import com.google.android.gms.maps.GoogleMap
import android.app.Activity
import android.os.Bundle
import java.util.ArrayList
import com.health.app.R
import android.annotation.SuppressLint
import com.karumi.dexter.Dexter
import com.karumi.dexter.listener.single.PermissionListener
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.PermissionToken
import com.health.app.activities.nearByDoctors.NearByDoctorsActivity
import java.lang.Exception
import android.content.DialogInterface
import android.content.Intent
import android.net.Uri
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.CameraUpdate
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener
import android.text.TextUtils
import com.health.app.activities.AppointmentScreen
import android.widget.Toast
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener
import android.util.Log
import androidx.annotation.RequiresApi
import android.os.Build
import android.graphics.drawable.Drawable
import android.graphics.Canvas
import android.graphics.Bitmap
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AlertDialog
import com.google.android.gms.maps.model.*
import com.health.app.databinding.ActivityNearByDoctorsBinding
import com.karumi.dexter.listener.PermissionRequest

class NearByDoctorsActivity : AppCompatActivity(), OnMapReadyCallback {
    var binding: ActivityNearByDoctorsBinding? = null
    var nearByList: MutableList<NearByListModel>? = null
    var locationManager: LocationManager? = null
    private var myGoogleMap: GoogleMap? = null
    var gps_enabled = false
    var network_enabled = false
    var context: Activity? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNearByDoctorsBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        context = this@NearByDoctorsActivity
        setMapAsync()
        checkPermission()
        binding!!.btnBack.setOnClickListener { v: View? -> onBackPressed() }
    }

    private fun setDataInList() {
        nearByList = ArrayList()
        (nearByList as ArrayList<NearByListModel>).add(NearByListModel("Dermatologist", 45.3581496, 18.9935639, R.drawable.skin))
        (nearByList as ArrayList<NearByListModel>).add(
            NearByListModel(
                "Cardiologist",
                45.2926035,
                18.8183691,
                R.drawable.cardiology
            )
        )
        (nearByList as ArrayList<NearByListModel>).add(
            NearByListModel(
                "Psychiartrist",
                45.5580019,
                18.7137024,
                R.drawable.mentaldisorder
            )
        )
        (nearByList as ArrayList<NearByListModel>).add(NearByListModel("Neurologist", 45.5580012, 18.7537011, R.drawable.neurology))
        (nearByList as ArrayList<NearByListModel>).add(
            NearByListModel(
                "General Physician",
                45.4887173,
                18.0980012,
                R.drawable.doctor
            )
        )
        (nearByList as ArrayList<NearByListModel>).add(NearByListModel("Gynecology", 45.5580022, 18.8037029, R.drawable.gynecology))
        (nearByList as ArrayList<NearByListModel>).add(
            NearByListModel(
                "Nutritional Disorder",
                45.1310249,
                18.6823776,
                R.drawable.diet
            )
        )
    }

    @SuppressLint("NewApi")
    private fun checkPermission() {
        Dexter.withContext(context).withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
            .withListener(object : PermissionListener {
                override fun onPermissionGranted(permissionGrantedResponse: PermissionGrantedResponse) {
                    if (context != null) {
                        
                        checkLocationServices()
                    }
                }

                override fun onPermissionDenied(permissionDeniedResponse: PermissionDeniedResponse) {
                   
                    if (permissionDeniedResponse.isPermanentlyDenied) {
                        showSettingsDialog()
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissionRequest: PermissionRequest,
                    permissionToken: PermissionToken
                ) {
                    permissionToken.continuePermissionRequest()
                }
            }).check()
        requestPermissions(
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            REQUEST_CODE_MAP_PERMISSION
        )
    }

    private fun checkLocationServices() {
        locationManager = context!!.getSystemService(LOCATION_SERVICE) as LocationManager
        try {
            gps_enabled = locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)
        } catch (ignored: Exception) {
        }
        try {
            network_enabled = locationManager!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        } catch (ignored: Exception) {
        }

        
        if (!gps_enabled && !network_enabled) {
         
            AlertDialog.Builder(context!!)
                .setTitle("Turn on location services.")
                .setMessage("This app needs location to use this feature. You can grant it in app settings.")
                .setPositiveButton("GOTO SETTINGS") { paramDialogInterface: DialogInterface?, paramInt: Int ->
                    context!!.startActivity(
                        Intent(
                            Settings.ACTION_LOCATION_SOURCE_SETTINGS
                        )
                    )
                }
                .setNegativeButton("Cancel") { dialogInterface: DialogInterface?, i: Int -> }
                .setCancelable(false)
                .show()
        } else {
            setDataInList()
        }
    }

    private fun showSettingsDialog() {
        val builder = AlertDialog.Builder(
            context!!
        )
        builder.setTitle("Need Permissions")
        builder.setMessage("This app needs permission to use this feature. You can grant them in app settings.")
        builder.setPositiveButton("GOTO SETTINGS") { dialog: DialogInterface, which: Int ->
            dialog.cancel()
            openSettings()
        }
        builder.setNegativeButton("Cancel") { dialog: DialogInterface, which: Int -> dialog.cancel() }
        builder.setCancelable(false)
        builder.show()
    }

    private fun openSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        val uri = Uri.fromParts("package", context!!.packageName, null)
        intent.data = uri
        startActivityForResult(intent, REQUEST_CODE_MAP_PERMISSION)
    }

    private fun setMapAsync() {
        val fragment =
            supportFragmentManager.findFragmentById(R.id.google_map) as SupportMapFragment?
        fragment?.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        myGoogleMap = googleMap
        if (nearByList == null) {
            nearByList = ArrayList()
            checkPermission()
        } else {
            showMarkersOnMap(nearByList!!)
        }
        val latLng = LatLng(45.5544215, 18.6975751)
        val markerOptions = MarkerOptions().position(latLng)
        markerOptions.title("Your Location")
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
        myGoogleMap!!.addMarker(markerOptions)

   
        if (myGoogleMap != null) {
            val cameraPosition = CameraPosition.Builder()
                .target(latLng)
                .zoom(12f)
                .build()
            val cu = CameraUpdateFactory.newCameraPosition(cameraPosition)
            myGoogleMap!!.animateCamera(cu)
        }
        
        myGoogleMap!!.setOnInfoWindowClickListener { marker: Marker ->
            val markerTitle = marker.title

            
            if (!TextUtils.isEmpty(markerTitle)) {
                val i = Intent(context, AppointmentScreen::class.java)
                i.putExtra("type", markerTitle)
                startActivity(i)
            } else {
                Toast.makeText(
                    this,
                    "Doctor not found for category : $markerTitle",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        googleMap.setOnMarkerClickListener { marker: Marker? -> false }
    }

    private fun showMarkersOnMap(nearByList: List<NearByListModel>) {
        try {
            myGoogleMap!!.clear()
        } catch (e: Exception) {
            Log.d("MapFragment", "RemoveMarker$e")
        }
        var latLng: LatLng? = null
        for (i in nearByList.indices) {
           
            latLng = LatLng(
                nearByList[i].lat,
                nearByList[i].lng
            )
            val markerTitle = nearByList[i].type
            val snippet = nearByList[i].type
            val bitmapDescriptor = bitmapDescriptorMarkerIcon

           
            if (myGoogleMap != null) {
                val markerOptions = MarkerOptions()
                    .position(latLng)
                    .title(markerTitle)
                    .snippet(snippet)
                    .icon(bitmapDescriptor)
                myGoogleMap!!.addMarker(markerOptions)!!.showInfoWindow()
            }
        }
       
    }


    @get:SuppressLint("UseCompatLoadingForDrawables")
    private val bitmapDescriptorMarkerIcon: BitmapDescriptor
        get() {
           
            val drawable: Drawable? = context!!.getDrawable(R.drawable.ic_baseline_doctor_pin)
            return getMarkerIconFromDrawable(drawable, 80, 80)
        }

    private fun getMarkerIconFromDrawable(drawable: Drawable?, width: Int, height: Int): BitmapDescriptor {
        val canvas = Canvas()
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        canvas.setBitmap(bitmap)
        drawable!!.setBounds(0, 0, width, width)
        drawable.draw(canvas)
        return BitmapDescriptorFactory.fromBitmap(bitmap)
    }

    companion object {
        const val REQUEST_CODE_MAP_PERMISSION = 101
    }
}