package com.health.app.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.health.app.databinding.ActivityAppointmentDetailScreenBinding

class AppointmentDetailScreen : AppCompatActivity() {
    var binding: ActivityAppointmentDetailScreenBinding? = null
    var mChatList: List<BookAppointments>? = null
    lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppointmentDetailScreenBinding.inflate(layoutInflater)
        setContentView(binding!!.root)

        initViews()
    }

    private fun initViews() {

        mChatList = ArrayList()
        firebaseAuth = FirebaseAuth.getInstance()

  
        val intent = intent
        val data: BookAppointments? =
            intent.getSerializableExtra("appointment_data") as BookAppointments?

       
        binding!!.tvName.text = data!!.name
        binding!!.tvHospital.text = data.hospital
        binding!!.tvExperience.text = data.experience
        binding!!.dcType.text = data.dcType
        binding!!.tvDate.text = data.date
        binding!!.tvTime.text = data.time

        binding!!.btnCancelAppointment.setOnClickListener(View.OnClickListener {
            cancelAppointment(data.time_stamp)
        })
    }

    private fun cancelAppointment(timeStamp: String) {
        val ref = FirebaseDatabase.getInstance().reference.child("book_appointments")
        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                (mChatList as ArrayList<BookAppointments>).clear()
                for (snapshot in snapshot.children) {
                    val chat = snapshot.getValue(BookAppointments::class.java)
                    if (chat!!.patient_uid == firebaseAuth.uid.toString()) {
                        if (chat.time_stamp == timeStamp) {
                            ref.child(chat.time_stamp).removeValue()
                            Toast.makeText(applicationContext, "Appointment Cancelled", Toast.LENGTH_LONG).show()
                            onBackPressed()
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })
    }
}