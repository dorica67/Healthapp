package com.health.app.activities
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.format.DateFormat
import android.util.Log
import android.view.View
import android.widget.DatePicker
import android.widget.TimePicker
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.health.app.databinding.ActivityAppointmentScreenBinding
import java.util.*
import kotlin.collections.HashMap

class AppointmentScreen : AppCompatActivity(), DatePickerDialog.OnDateSetListener,
TimePickerDialog.OnTimeSetListener {
    private lateinit var database: DatabaseReference
    private  lateinit var firebaseAuth: FirebaseAuth
    private lateinit var binding: ActivityAppointmentScreenBinding
    var day = 0
    var month: Int = 0
    var year: Int = 0
    var hour: Int = 0
    var minute: Int = 0
    var myDay = 0
    var myMonth: Int = 0
    var myYear: Int = 0
    var myHour: Int = 0
    var myMinute: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppointmentScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        print(firebaseAuth.uid)
        val type = intent.getStringExtra("type")
        database = FirebaseDatabase.getInstance().reference

        var name = ""
        var speciality = ""
        var experience = ""
        val calendar: Calendar = Calendar.getInstance()
        day = calendar.get(Calendar.DAY_OF_MONTH)
        month = calendar.get(Calendar.MONTH)
        year = calendar.get(Calendar.YEAR)
        binding.tvDate.text= "$day-$month-$year"
        binding.tvTime.text = "${calendar.get(Calendar.HOUR_OF_DAY)}:${calendar.get(Calendar.MINUTE)}"
        binding.btnDate.setOnClickListener {

            val datePickerDialog =
                DatePickerDialog(this@AppointmentScreen, this@AppointmentScreen, year, month,day)
            datePickerDialog.show()

        }

        binding.btnBack.setOnClickListener {
            onBackPressed()
        }



        when(type){
            "Dermatologist"->{
                name = "Alex Khan"
                speciality = "Dermatologist"
                experience = "6+ years"
            }
            "Cardiologist"->{
                name = "Maria Fida"
                speciality = "Cardiologist"
                experience = "16+ years"
            }
            "Neurologist"->{
                name = "John Abraham"
                speciality = "Neurologist"
                experience = "9+ years"
            }
            "Nutritional Disorder"->{
                name = "Pat Cummins"
                speciality = "Nutritional Disorder"
                experience = "3+ years"
            }
            "Psychiartrist"->{
                name = "George Bell"
                speciality = "Psychiartrist"
                experience = "7+ years"
            }
            "General Physician"->{
                name = "Ben Stokes"
                speciality = "General Physician"
                experience = "18+ years"

            }
            "Gynecology"->{
                name = "Xeng Weng"
                speciality = "Gynecologist"
                experience = "9+ years"
            }
        }
        binding.tvName.text = name
        binding.tvHospital.text = "City Hospital"
        binding.tvExperience.text = experience
        binding.dcType.text = speciality

//        try {

            binding.btnAppointment.setOnClickListener {

                try {
                    binding.pb.visibility = View.VISIBLE
                    binding.ll.visibility = View.GONE
                    val currentTimestamp = System.currentTimeMillis()

                    val hashMap = HashMap<String,String>()
                    hashMap["patient_uid"] = ""+firebaseAuth.uid
                    hashMap["specialist"] = ""+speciality
                    hashMap["time"] = ""+binding.tvTime.text.toString()
                    hashMap["date"] = ""+binding.tvDate.text.toString()

                    database.child("appointments").child(currentTimestamp.toString()).setValue(hashMap)
                        .addOnCompleteListener {
                            if (it.isSuccessful){
                                
                                finish()
                            }
                        }.addOnFailureListener {
                            binding.pb.visibility = View.GONE
                            binding.ll.visibility = View.VISIBLE
                        }

                    
                    hashMap["name"] = ""+binding.tvName.text.toString()
                    hashMap["dcType"] = ""+binding.dcType.text.toString()
                    hashMap["hospital"] = ""+binding.tvHospital.text.toString()
                    hashMap["experience"] = ""+binding.tvExperience.text.toString()
                    hashMap["time_stamp"] = ""+ currentTimestamp.toString()

                    database.child ("book_appointments").child(currentTimestamp.toString())
                        .setValue(hashMap)
                        .addOnCompleteListener {
                            if (it.isSuccessful) {
                                binding.pb.visibility = View.GONE
                                binding.ll.visibility = View.VISIBLE
                                Toast.makeText(this, "Appointment Fixed", Toast.LENGTH_LONG).show()
                                finish()
                            }
                        }.addOnFailureListener {
                            binding.pb.visibility = View.GONE
                            binding.ll.visibility = View.VISIBLE
                        }
                }catch (e:Exception){

                    var a = e
                    Log.d("TAG", a.toString());
                    Log.i("Error","Error in")

                }

            }
//        }catch (e:Exception){
//
//            Log.i("Error","Error Occured")
//        }



    }

    override fun onDateSet(p0: DatePicker?, p1: Int, p2: Int, p3: Int) {
        myDay = p3
        myYear = p1
        myMonth = p2
        val calendar: Calendar = Calendar.getInstance()
        hour = calendar.get(Calendar.HOUR)
        minute = calendar.get(Calendar.MINUTE)
        val timePickerDialog = TimePickerDialog(this@AppointmentScreen, this, hour, minute,
            DateFormat.is24HourFormat(this))
        timePickerDialog.show()
    }

    override fun onTimeSet(p0: TimePicker?, p1: Int, p2: Int) {
        myHour = p1
        myMinute = p2
        binding.tvDate.text = "${myDay}-$myMonth-$myYear"
        binding.tvTime.text = "$myHour:$myMinute"
    }
}