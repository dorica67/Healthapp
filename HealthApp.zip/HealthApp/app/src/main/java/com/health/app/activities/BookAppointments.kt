package com.health.app.activities

import java.io.Serializable

class BookAppointments : Serializable{
    var date:String=""
    var patient_uid:String=""
    var specialist:String=""
    var time:String=""
    var name:String=""
    var dcType:String=""
    var hospital:String=""
    var experience:String=""
    var time_stamp:String=""
    constructor()
    constructor(date: String, patient_uid: String, specialist: String, time: String, name: String, dcType: String, hospital: String, experience: String, time_stamp: String) {
        this.date = date
        this.patient_uid = patient_uid
        this.specialist = specialist
        this.time = time
        this.name = name
        this.dcType = dcType
        this.hospital = hospital
        this.experience = experience
        this.time_stamp = time_stamp
    }


}