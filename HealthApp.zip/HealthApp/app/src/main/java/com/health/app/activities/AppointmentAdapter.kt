package com.health.app.activities

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.health.app.R


class AppointmentAdapter(private val dataSet: ArrayList<BookAppointments>, val context: Context) : RecyclerView.Adapter<AppointmentAdapter.ViewHolder>() {


    
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvType: TextView = view.findViewById(R.id.tvType)
        val tvDate: TextView = view.findViewById(R.id.tvDate)


    }

   
    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
        
        val view = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.apoint_item, viewGroup, false)

        return ViewHolder(view)
    }

   
    override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {

        
        val app = dataSet[position]
        viewHolder.tvType.text = app.specialist
        viewHolder.tvDate.text = "Appointment Date: "+app.date+" "+app.time

        viewHolder.itemView.setOnClickListener(View.OnClickListener {
            val appointmentData = dataSet[position]
            val intent = Intent(context, AppointmentDetailScreen::class.java)
            intent.putExtra("appointment_data", appointmentData)
            context.startActivity(intent)
        })
    }

    override fun getItemCount() = dataSet.size

}
