package com.health.app.activities

import androidx.appcompat.app.AppCompatActivity
import java.util.ArrayList
import com.health.app.activities.SpecialityModel
import androidx.recyclerview.widget.RecyclerView
import com.health.app.activities.SpecialityAdapter
import androidx.recyclerview.widget.RecyclerView.LayoutManager
import android.app.Activity
import android.os.Bundle
import android.text.TextWatcher
import android.text.Editable
import java.util.Locale
import com.health.app.R
import androidx.recyclerview.widget.LinearLayoutManager
import com.health.app.databinding.ActivitySpecialityScreenTwoBinding

class SpecialityScreenTwo : AppCompatActivity() {
    var binding: ActivitySpecialityScreenTwoBinding? = null
    private var mExampleList: ArrayList<SpecialityModel>? = null
    private var mAdapter: SpecialityAdapter? = null
    private var mLayoutManager: LayoutManager? = null
    var context: Activity? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySpecialityScreenTwoBinding.inflate(
            layoutInflater
        )
        setContentView(binding!!.root)
        context = this@SpecialityScreenTwo
        createExampleList()
        buildRecyclerView()
        binding!!.editSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                filter(s.toString())
            }
        })
    }

    private fun filter(text: String) {
        val filteredList = ArrayList<SpecialityModel>()
        for (item in mExampleList!!) {
            if (item.name.lowercase(Locale.getDefault())
                    .contains(text.lowercase(Locale.getDefault()))
            ) {
                filteredList.add(item)
            }
        }
        mAdapter!!.filterList(filteredList)
    }

    private fun createExampleList() {
        mExampleList = ArrayList()
        mExampleList!!.add(SpecialityModel("Dermatologist", R.drawable.skin))
        mExampleList!!.add(SpecialityModel("Cardiologist", R.drawable.cardiology))
        mExampleList!!.add(SpecialityModel("Psychiartrist", R.drawable.mentaldisorder))
        mExampleList!!.add(SpecialityModel("Neurologist", R.drawable.neurology))
        mExampleList!!.add(SpecialityModel("General Physician", R.drawable.doctor))
        mExampleList!!.add(SpecialityModel("Gynecology", R.drawable.gynecology))
        mExampleList!!.add(SpecialityModel("Nutritional Disorder", R.drawable.diet))
    }

    private fun buildRecyclerView() {
        binding!!.recyclerView.setHasFixedSize(true)
        mLayoutManager = LinearLayoutManager(this)
        mAdapter = mExampleList?.let { context?.let { it1 -> SpecialityAdapter(it, it1) } }
        binding!!.recyclerView.layoutManager = mLayoutManager
        binding!!.recyclerView.adapter = mAdapter
    }
}