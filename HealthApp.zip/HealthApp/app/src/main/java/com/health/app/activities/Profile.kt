package com.health.app.activities

class Profile{
    var fullname:String=""
    var number:String=""
    var gender:String=""
    var uid:String=""
    var address:String=""
    var age:String=""
    constructor()
    constructor(
        fullname: String,
        number: String,
        gender: String,
        uid: String,
        address: String,
        age: String
    ) {
        this.fullname = fullname
        this.number = number
        this.gender = gender
        this.uid = uid
        this.address = address
        this.age = age
    }

}
