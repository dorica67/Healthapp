package com.health.app.activities

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.health.app.activities.nearByDoctors.NearByDoctorsActivity
import com.health.app.databinding.ActivityDashboardBinding
import java.util.*

class Dashboard : AppCompatActivity() {
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var binding: ActivityDashboardBinding
    private var fusedLocationClient: FusedLocationProviderClient? = null
    private var lastLocation: Location? = null
    private var latitudeLabel: String? = null
    private var longitudeLabel: String? = null

    var mChatlist: List<BookAppointments>? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mChatlist = ArrayList()

        loadData()


        binding.btnProfile.setOnClickListener {
            startActivity(Intent(this@Dashboard, ProfileScreen::class.java))
        }
        binding.btnSpecial.setOnClickListener {
            startActivity(Intent(this@Dashboard, SpecialityScreenTwo::class.java))
        }
        binding.btnAllAppointments.setOnClickListener {
            startActivity(Intent(this@Dashboard, MyAppointmentActivity::class.java))
        }
        binding.btnSettings.setOnClickListener {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.drberg.com/"))
            startActivity(browserIntent)
        }
        binding.btnNearByDoctors.setOnClickListener {
            startActivity(Intent(this@Dashboard, NearByDoctorsActivity::class.java))
        }

        firebaseAuth = FirebaseAuth.getInstance()
        checkUser()
        binding.btnLogout.setOnClickListener {
            firebaseAuth.signOut()
            checkUser()
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

    }

    private fun checkUser() {
        val firebaseUser = firebaseAuth.currentUser
        val type = intent.getStringExtra("type")

        when {
            firebaseUser == null -> {
                val intent = Intent(this, Welcome::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

                startActivity(intent)
                finish()
            }
            type.equals("otp") -> {
                val phone = firebaseUser.phoneNumber
                binding.tvPhone.text = phone.toString()

            }
            type.equals("google") -> {
                val email = firebaseUser.email
                binding.tvPhone.text = email.toString()

            }
            type.equals("email") -> {
                val email = firebaseUser.email
                binding.tvPhone.text = email.toString()
            }
            type.equals("facebook") -> {
                val email = firebaseUser.displayName
                binding.tvPhone.text = email.toString()
            }
        }
    }


    public override fun onStart() {
        super.onStart()
        if (!checkPermissions()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions()
            }
        } else {
            getLastLocation()
        }
    }

    private fun getLastLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
           
            return
        }
        fusedLocationClient?.lastLocation!!.addOnCompleteListener(this) { task ->
            if (task.isSuccessful && task.result != null) {
                lastLocation = task.result
                latitudeLabel = (lastLocation)!!.latitude.toString()
                longitudeLabel = (lastLocation)!!.longitude.toString()
                Log.i("location", "$latitudeLabel $longitudeLabel")
            } else {
                Log.w(TAG, "getLastLocation:exception", task.exception)
                showMessage("No location detected. Make sure location is enabled on the device.")
            }
        }
    }

    private fun showMessage(string: String) {

        Toast.makeText(this@Dashboard, string, Toast.LENGTH_LONG).show()

    }

    private fun showSandbar(
        mainTextStringId: String, actionStringId: String,
        listener: View.OnClickListener
    ) {
        Toast.makeText(this@Dashboard, mainTextStringId, Toast.LENGTH_LONG).show()
    }

    private fun checkPermissions(): Boolean {
        val permissionState = ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        return permissionState == PackageManager.PERMISSION_GRANTED
    }

    private fun startLocationPermissionRequest() {
        ActivityCompat.requestPermissions(
            this@Dashboard,
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION),
            REQUEST_PERMISSIONS_REQUEST_CODE
        )
    }

    private fun requestPermissions() {
        val shouldProvideRationale = ActivityCompat.shouldShowRequestPermissionRationale(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (shouldProvideRationale) {
            Log.i(TAG, "Displaying permission rationale to provide additional context.")
            showSandbar("Location permission is needed for core functionality", "Okay",
                View.OnClickListener {
                    startLocationPermissionRequest()
                })
        } else {
            Log.i(TAG, "Requesting permission")
            startLocationPermissionRequest()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Log.i(TAG, "onRequestPermissionResult")
        if (requestCode == REQUEST_PERMISSIONS_REQUEST_CODE) {
            when {
                grantResults.isEmpty() -> {
                   
                    Log.i(TAG, "User interaction was cancelled.")
                }
                grantResults[0] == PackageManager.PERMISSION_GRANTED -> {
                  
                    getLastLocation()
                }
                else -> {
                    showSandbar("Permission was denied", "Settings",
                        View.OnClickListener {
                            .
                            val intent = Intent()
                            intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                            val uri = Uri.fromParts(
                                "package",
                                Build.DISPLAY, null
                            )
                            intent.data = uri
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            startActivity(intent)
                        }
                    )
                }
            }
        }
    }

    companion object {
        private val TAG = "LocationProvider"
        private val REQUEST_PERMISSIONS_REQUEST_CODE = 34
    }


    fun loadData() {
        val ref = FirebaseDatabase.getInstance().reference.child("book_appointments")
        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                (mChatlist as ArrayList<BookAppointments>).clear()
                for (snapshot in snapshot.children) {
                    val chat = snapshot.getValue(BookAppointments::class.java)
                    if (chat!!.patient_uid == firebaseAuth.uid.toString()) {
                        (mChatlist as ArrayList<BookAppointments>).add(chat)

                        for (i in (mChatlist as ArrayList<BookAppointments>).indices) {
                            val completeDate: String =
                                (mChatlist as ArrayList<BookAppointments>).get(i).date
                            val completeTime: String =
                                (mChatlist as ArrayList<BookAppointments>).get(i).time
                            val timeStamp: String =
                                (mChatlist as ArrayList<BookAppointments>).get(i).time_stamp

                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })
    }

    override fun onResume() {
        super.onResume()
        loadData()
    }
}