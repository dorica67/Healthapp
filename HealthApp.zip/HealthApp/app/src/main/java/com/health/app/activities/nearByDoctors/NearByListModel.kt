package com.health.app.activities.nearByDoctors

class NearByListModel(var type: String, var lat: Double, var lng: Double, var image: Int)