package com.health.app.activities

class Appointment {
    var date:String=""
    var patient_uid:String=""
    var specialist:String=""
    var time:String=""
    constructor()
    constructor(date: String, patient_uid: String, specialist: String, time: String) {
        this.date = date
        this.patient_uid = patient_uid
        this.specialist = specialist
        this.time = time
    }


}