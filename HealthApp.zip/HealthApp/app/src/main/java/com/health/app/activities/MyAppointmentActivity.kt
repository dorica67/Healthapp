package com.health.app.activities

import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.RecoverySystem
import android.view.View.inflate
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.health.app.R
import com.health.app.databinding.ActivityLoginWithEmailBinding
import com.health.app.databinding.ActivityMyAppointmentBinding
import com.health.app.databinding.ActivityOtpBinding

class MyAppointmentActivity : AppCompatActivity() {
    var mChatlist: List<BookAppointments>? = null
    lateinit var firebaseAuth: FirebaseAuth
    private lateinit var binding: ActivityMyAppointmentBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyAppointmentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        mChatlist = ArrayList()
        binding.btnBack.setOnClickListener {
            onBackPressed()
        }
        loadData()

    }

    fun loadData() {
        val ref = FirebaseDatabase.getInstance().reference.child("book_appointments")
        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                binding.recyclerView.adapter = null
                (mChatlist as ArrayList<BookAppointments>).clear()
                for (snapshot in snapshot.children) {
                    val chat = snapshot.getValue(BookAppointments::class.java)
                    if (chat!!.patient_uid == firebaseAuth.uid.toString()) {
                        (mChatlist as ArrayList<BookAppointments>).add(chat)
                    }
                    val appointAdapter = AppointmentAdapter(
                        (mChatlist as ArrayList<BookAppointments>),
                        this@MyAppointmentActivity
                    )
                    binding.recyclerView.adapter = appointAdapter

                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })
    }

    override fun onResume() {
        super.onResume()
        loadData()
    }
}