package com.health.app.activities

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.health.app.databinding.ActivitySpecialityScreenBinding


class SpecialityScreen : AppCompatActivity() {
    private lateinit var binding: ActivitySpecialityScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySpecialityScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { view: View? -> onBackPressed() }

        binding.btnDerma.setOnClickListener {
            startActivity(Intent(this@SpecialityScreen,AppointmentScreen::class.java).putExtra("type","derma"))
        }
        binding.btnCardiology.setOnClickListener {
            startActivity(Intent(this@SpecialityScreen,AppointmentScreen::class.java).putExtra("type","cardio"))

        }
        binding.btnGeneral.setOnClickListener {
            startActivity(Intent(this@SpecialityScreen,AppointmentScreen::class.java).putExtra("type","general"))

        }
        binding.btnGynecology.setOnClickListener {
            startActivity(Intent(this@SpecialityScreen,AppointmentScreen::class.java).putExtra("type","gyne"))

        }
        binding.btnNeurology.setOnClickListener {
            startActivity(Intent(this@SpecialityScreen,AppointmentScreen::class.java).putExtra("type","neu"))

        }
        binding.btnNutritional.setOnClickListener {
            startActivity(Intent(this@SpecialityScreen,AppointmentScreen::class.java).putExtra("type","nut"))

        }
        binding.btnPsychiartrist.setOnClickListener {
            startActivity(Intent(this@SpecialityScreen,AppointmentScreen::class.java).putExtra("type","psy"))

        }
    }

    private fun searchDoctor(str: String) {
        when(str) {
            "Sun" -> println("Sun is a Star")
            "Moon" -> println("Moon is a Satellite")
            "Earth" -> println("Earth is a planet")
            else -> println("I don't know anything about it")
        }
    }
}