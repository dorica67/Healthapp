package com.health.app.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.core.content.ContentProviderCompat.requireContext
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.health.app.R
import com.health.app.databinding.ActivityProfileScreenBinding
import java.lang.Exception
import java.util.HashMap

class ProfileScreen : AppCompatActivity() {

    var firebaseAuth: FirebaseAuth? = null
    private lateinit var binding: ActivityProfileScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileScreenBinding.inflate(layoutInflater);
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        binding.btnSave.setOnClickListener { view: View? -> saveUserData() }
        binding.btnBack.setOnClickListener { view: View? -> onBackPressed() }
        loadMyInfo()
    }

    private fun saveUserData() {
        val name = binding.etName.text.toString()
        val address: String = binding.etAddress.text.toString()
        val age: String = binding.etAge.text.toString()
        val number: String = binding.etphoneNumber.text.toString()
        val gender = binding.etGender.selectedItem.toString()
        val hashMap = HashMap<String, String>()
        hashMap["fullname"] = "" + name
        hashMap["age"] = "" + age
        hashMap["number"] = "" + number
        hashMap["gender"] = "" + gender
        hashMap["address"] = "" + address
        hashMap["uid"] = "" + firebaseAuth!!.uid
        val ref = FirebaseDatabase.getInstance().getReference("users")

        ref.child(firebaseAuth!!.uid!!).setValue(hashMap).addOnSuccessListener { unused: Void? ->
            Toast.makeText(
                this@ProfileScreen,
                "Data Saved Successfully",
                Toast.LENGTH_SHORT
            ).show()
        }.addOnFailureListener { e ->
            var a = e
            Log.d("TAG", a.toString());
        }
    }

    private fun loadMyInfo() {
        Log.i("uid", firebaseAuth!!.uid!!)
        val ref =
            FirebaseDatabase.getInstance().reference.child("users").child(firebaseAuth!!.uid!!)
        ref
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    val prof: Profile? = snapshot.getValue(Profile::class.java)
                    if (prof != null) {
                        Log.i("user", prof.fullname)
                        binding.etName.setText(prof.fullname)
                        binding.etAddress.setText(prof.address)
                        binding.etphoneNumber.setText(prof.number)
                        binding.etAge.setText(prof.age)
                        when (prof.gender) {
                            "male" -> {
                                binding.etGender.setSelection(0)
                            }
                            "female" -> {
                                binding.etGender.setSelection(1)
                            }
                            else -> {
                                binding.etGender.setSelection(2)
                            }
                        }
                    }


                    Log.i("data", "loop work")
                }

                override fun onCancelled(error: DatabaseError) {

                }
            })
    }
}