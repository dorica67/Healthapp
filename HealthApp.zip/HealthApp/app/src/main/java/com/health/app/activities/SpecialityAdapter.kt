package com.health.app.activities

import java.util.ArrayList
import android.app.Activity
import androidx.recyclerview.widget.RecyclerView
import android.view.ViewGroup
import android.view.LayoutInflater
import android.annotation.SuppressLint
import com.bumptech.glide.Glide
import android.content.Intent
import android.view.View
import com.health.app.databinding.SpecialityItemBinding

class SpecialityAdapter(var modelList: ArrayList<SpecialityModel>, var context: Activity) :
    RecyclerView.Adapter<SpecialityAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            SpecialityItemBinding.inflate(
                LayoutInflater.from(
                    context
                ), parent, false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, @SuppressLint("RecyclerView") position: Int) {
        val data = modelList[position]
        Glide.with(context).load(data.image).into(holder.binding.imageView)
        holder.binding.txtName.text = data.name
        holder.itemView.setOnClickListener { view: View? ->
            val intent = Intent(context, AppointmentScreen::class.java)
            intent.putExtra("type", modelList[position].name)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return modelList.size
    }

    class ViewHolder(var binding: SpecialityItemBinding) : RecyclerView.ViewHolder(
        binding.root
    )

    @SuppressLint("NotifyDataSetChanged")
    fun filterList(filteredList: ArrayList<SpecialityModel>) {
        modelList = filteredList
        notifyDataSetChanged()
    }
}